        <?php $this->load->view($footerJs); 
       ?>
        
    </body>
</html>